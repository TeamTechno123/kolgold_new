<?php include('header.php'); ?>

<section class="page-default">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="text-white"> Disclaimer</h1>
          <p class="text-white text-center">Home /  Disclaimer </p>
      </div>
    </div>
  </div>
</section>

<section class="page-sec-two">
  <div class="container">
    <div class="row">
      <div class="terms">
        <div class="row">
          <div class="col-md-12">
              <p>The data contained in this site is for general data purposes allegorically. The data is given by kolgold.com recalling that we attempt to stay up with the latest and right, we make no representations or affirmations of any sort, express or recommended, about the completeness, exactness, immovable quality, appropriateness or accessibility concerning the site or the data, things, benefits, or related arrangement contained on the site for any reason. Any dependency you put on such data is along these lines by and large at your own particular risk.</p>
              <p>In no occasion,we will be committed for any misfortune or harm including without hindrance, roaming or gigantic hardship or hurt, any difficulty or wickedness at all ascending out of loss of information or points of interest creating out of, or as to, the utilization of this site.</p>
              <p>Through this site you can relationship with different areas which are not under the control of kolgold.com. We have no effect over the nature, substance and accessibility of those objectives. The possibility of any affiliations does not by any extend of the creative energy propose a recommendation or handle the perspective communicated inside them.</p>
              <p>Each exertion is made to keep the site up and running easily. All things considered, kolgold.com acknowledge no commitment for, and won't be at risk for, the site being by chance closed off in perspective of specific issues outside our ability to control.</p>
          </div>
        </div>
      </div>  
    </div>
  </div>      
        
</section>

<?php include('footer.php'); ?>