<?php include('header.php'); ?>

<section class="page-default">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <h1 class="text-white">My Account</h1>
          <p class="text-white text-center">Home / My Account </p>
      </div>
    </div>
  </div>
</section>

<section class="page-sec-login">
  <div class="container">
    <div class="row">    
           

            
          <div class="col-md-6 offset-md-3 text-center"> 
           <div class="">
              <h4 class="f-22 mb-3">Forgot Password </h4>
            </div>              
               <div class="form-group">
                  <label >Email Address *</label>
                  <input type="text" class="form-control form-control-sm" id="" placeholder="Emter Email ">
                </div>
                <p class="f-12">A password will be sent to your email address.</p>
                <p class="f-12">Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our privacy policy.</p>
                <div class="text-center mt-5">
                  <button type="button" class="btn btn-success round">Reset Password</button>
                </div>
                
          </div>

          

          
        </div>
      </div> 
        
</section>



<?php include('footer.php'); ?>

