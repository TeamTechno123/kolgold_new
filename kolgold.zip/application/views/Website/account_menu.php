<ul class="account-menu">
	<h4 class="f-18">My Account</h4>
	<li> <a href="<?php echo base_url(); ?>website/my_account">Dashboard</a></li>
	<li> <a href="<?php echo base_url(); ?>website/order">Orders</a></li>
	<li> <a href="<?php echo base_url(); ?>website/address">Addresses</a></li>
	<li> <a href="<?php echo base_url(); ?>website/account">Account details</a></li>
	<li> <a href="<?php echo base_url(); ?>website/wishlist">Wishlist</a></li>
	<li> <a href="<?php echo base_url(); ?>website/logout">Logout</a></li>
</ul>